window.PROJECT_DATA = {
  "project": {
    "title": "Trợ lý AI học tập",
    "english": "Learning AI Assistant",
    "subtitle": "Ứng dụng trí tuệ nhân tạo để hỗ trợ học tập thông minh hơn",
    "description": "Một chatbot AI đóng vai trò như trợ giảng ảo, hỗ trợ học sinh tìm hiểu kiến thức, giải thích bài học và học tập chủ động hơn.",
    "surveyUrl": "https://docs.google.com/forms/d/e/1FAIpQLScW0PJGK9viXGjxNyDlh2Xe68wWVxoQs9y3fWEk8G-jJFYOzA/viewform?usp=dialog"
  },
  "objectives": [
    {
      "id": "1.1.a",
      "title": "Phỏng vấn và tổng hợp nhu cầu người dùng",
      "summary": "Tìm hiểu nhu cầu của các bên liên quan và chuyển dữ liệu thành User Stories chi tiết.",
      "status": "Đã tạo biểu mẫu – đang thu thập dữ liệu",
      "statusType": "progress",
      "steps": [
        "Tạo biểu mẫu khảo sát bằng Google Forms.",
        "Thu thập ý kiến từ học sinh và giáo viên.",
        "Phân loại nhu cầu và khó khăn học tập.",
        "Viết User Stories theo cấu trúc: Là…, tôi muốn…, để…"
      ],
      "outputs": [
        "Liên kết biểu mẫu khảo sát",
        "Kết quả khảo sát thực tế",
        "Bảng tổng hợp nhu cầu",
        "Danh sách User Stories có tiêu chí chấp nhận và mức ưu tiên"
      ],
      "example": "Là một học sinh, tôi muốn Trợ lý AI giải thích bài Toán theo từng bước để tôi hiểu cách giải thay vì chỉ nhận đáp án.",
      "tools": [
        "Google Forms",
        "Google Sheets hoặc Excel"
      ]
    },
    {
      "id": "1.2.e",
      "title": "Phân tích ranh giới giữa vai trò con người và AI",
      "summary": "Đánh giá cách con người và AI phối hợp trong các giai đoạn đồng sáng tạo.",
      "status": "Đang triển khai",
      "statusType": "progress",
      "steps": [
        "Phân chia vai trò ở giai đoạn lên ý tưởng, chuẩn bị dữ liệu, xây dựng, kiểm tra và ra quyết định.",
        "Ghi lại ví dụ thực tế về lúc AI hỗ trợ và lúc con người cần can thiệp.",
        "Đánh giá ưu điểm, hạn chế và đề xuất cách phối hợp tốt hơn."
      ],
      "outputs": [
        "Bảng phân chia vai trò người – AI",
        "Ví dụ thực tế trong dự án",
        "Đánh giá hiệu quả phối hợp",
        "Đề xuất cải thiện"
      ],
      "tools": [
        "Excel",
        "Word hoặc Google Docs"
      ]
    },
    {
      "id": "1.3.a",
      "title": "Xây dựng bộ tiêu chí đánh giá AI",
      "summary": "Tạo bộ tiêu chí có trọng số, thang điểm và phương pháp kiểm tra phù hợp với chatbot học tập.",
      "status": "Đã xây dựng tiêu chí đề xuất – cần kiểm thử",
      "statusType": "progress",
      "steps": [
        "Chọn tiêu chí kỹ thuật, trải nghiệm người dùng và an toàn.",
        "Xác định trọng số và thang điểm 1–5.",
        "Thử chatbot bằng câu hỏi thuộc nhiều môn học.",
        "Ghi điểm và tính kết quả sau khi có dữ liệu thử nghiệm."
      ],
      "outputs": [
        "Bảng 6 tiêu chí và trọng số",
        "Thang điểm 1–5",
        "Kịch bản kiểm thử",
        "Kết quả thử nghiệm thực tế"
      ],
      "tools": [
        "Excel hoặc Google Sheets",
        "Chatbot AI"
      ]
    },
    {
      "id": "1.3.e",
      "title": "Phân tích tình huống đạo đức khi sử dụng AI",
      "summary": "Phân tích tình huống có xung đột giá trị và đề xuất giải pháp có trách nhiệm.",
      "status": "Đã xây dựng tình huống – cần hoàn thiện phân tích",
      "statusType": "progress",
      "steps": [
        "Xác định tình huống: dùng dữ liệu học tập để cải thiện chatbot nhưng có nguy cơ ảnh hưởng quyền riêng tư.",
        "Phân tích lợi ích và rủi ro đối với học sinh, giáo viên và nhà trường.",
        "So sánh hậu quả của các phương án.",
        "Đề xuất giải pháp và giải thích lý do lựa chọn."
      ],
      "outputs": [
        "Mô tả tình huống đạo đức",
        "Phân tích ít nhất 3 bên liên quan",
        "Hậu quả của các phương án",
        "Giải pháp và lý do lựa chọn"
      ],
      "tools": [
        "Word hoặc Google Docs",
        "Excel"
      ]
    },
    {
      "id": "1.4.c",
      "title": "Phân tích sự thay đổi trong tư duy cá nhân",
      "summary": "Nhận diện và phân tích thay đổi trong cách suy nghĩ, học tập sau khi tương tác với AI.",
      "status": "Chờ minh chứng sau giai đoạn thử nghiệm",
      "statusType": "pending",
      "steps": [
        "Ghi lại cách học và sử dụng công nghệ trước khi thực hiện dự án.",
        "Viết nhật ký trong quá trình sử dụng và thử nghiệm AI.",
        "So sánh cách tìm kiếm thông tin, giải quyết bài tập và kiểm chứng thông tin trước – sau.",
        "Viết bài phản tư dựa trên trải nghiệm thật."
      ],
      "outputs": [
        "Bảng so sánh trước – sau",
        "Nhật ký sử dụng AI",
        "Ví dụ thực tế",
        "Bài phản tư cá nhân"
      ],
      "tools": [
        "Word hoặc Google Docs",
        "Excel"
      ]
    }
  ],
  "criteria": [
    {
      "name": "Độ chính xác",
      "weight": 30,
      "method": "So sánh câu trả lời với tài liệu đáng tin cậy."
    },
    {
      "name": "Khả năng giải thích",
      "weight": 20,
      "method": "Kiểm tra khả năng giải thích kiến thức theo từng bước."
    },
    {
      "name": "Tốc độ phản hồi",
      "weight": 10,
      "method": "Đo thời gian từ lúc gửi câu hỏi đến khi nhận câu trả lời."
    },
    {
      "name": "Trải nghiệm người dùng",
      "weight": 15,
      "method": "Thu thập đánh giá từ người dùng thử."
    },
    {
      "name": "An toàn thông tin",
      "weight": 15,
      "method": "Kiểm tra việc bảo vệ dữ liệu và hạn chế yêu cầu thông tin cá nhân."
    },
    {
      "name": "Khả năng xử lý câu hỏi",
      "weight": 10,
      "method": "Thử nhiều dạng câu hỏi và môn học khác nhau."
    }
  ],
  "roles": [
    {
      "stage": "Lên ý tưởng",
      "human": "Xác định vấn đề và nhu cầu người dùng.",
      "ai": "Đề xuất ý tưởng và tính năng."
    },
    {
      "stage": "Chuẩn bị dữ liệu",
      "human": "Chọn tài liệu phù hợp và kiểm tra nguồn.",
      "ai": "Hỗ trợ tóm tắt, phân loại tài liệu."
    },
    {
      "stage": "Xây dựng",
      "human": "Thiết kế, thiết lập và điều chỉnh chatbot.",
      "ai": "Hỗ trợ tạo nội dung và câu trả lời."
    },
    {
      "stage": "Kiểm tra",
      "human": "Kiểm chứng độ chính xác và phát hiện lỗi.",
      "ai": "Trả lời câu hỏi thử nghiệm."
    },
    {
      "stage": "Ra quyết định",
      "human": "Đưa ra quyết định cuối cùng và chịu trách nhiệm.",
      "ai": "Đề xuất phương án, không quyết định thay con người."
    }
  ],
  "ethics": {
    "situation": "Chatbot có thể cần dữ liệu học tập để cải thiện chất lượng câu trả lời. Tuy nhiên, thu thập quá nhiều dữ liệu có thể ảnh hưởng đến quyền riêng tư của học sinh.",
    "values": [
      "Sự tiện lợi và hiệu quả của AI",
      "Quyền riêng tư và bảo mật thông tin cá nhân"
    ],
    "stakeholders": [
      {
        "name": "Học sinh",
        "benefit": "Được hỗ trợ học tập nhanh chóng.",
        "risk": "Thông tin cá nhân có thể bị tiết lộ."
      },
      {
        "name": "Giáo viên",
        "benefit": "Có thêm công cụ hỗ trợ học sinh.",
        "risk": "Có thể phụ thuộc vào câu trả lời không chính xác của AI."
      },
      {
        "name": "Nhà trường",
        "benefit": "Có thêm công cụ cải thiện hoạt động học tập.",
        "risk": "Có thể phát sinh rủi ro về bảo mật dữ liệu."
      }
    ],
    "solutions": [
      "Chỉ thu thập dữ liệu thật sự cần thiết.",
      "Không yêu cầu thông tin cá nhân nhạy cảm.",
      "Thông báo rõ mục đích và cách sử dụng dữ liệu.",
      "Hạn chế quyền truy cập dữ liệu.",
      "Kiểm tra tính an toàn của hệ thống."
    ]
  }
};

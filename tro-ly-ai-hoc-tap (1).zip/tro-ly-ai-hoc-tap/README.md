# Trợ lý AI học tập – Website báo cáo dự án

Website tĩnh tương thích GitHub Pages, dùng HTML, CSS và JavaScript thuần.

## Chạy thử
Mở `index.html` bằng trình duyệt. Nếu muốn chạy local server, có thể dùng VS Code Live Server.

## Đưa lên GitHub Pages
1. Tạo repository mới trên GitHub, ví dụ `tro-ly-ai-hoc-tap`.
2. Upload toàn bộ nội dung thư mục này lên nhánh `main`.
3. Vào **Settings → Pages**.
4. Chọn **Deploy from a branch**, branch `main`, folder `/(root)`, rồi Save.
5. Đợi GitHub triển khai và mở địa chỉ Pages hiển thị trong phần Pages.

## Cập nhật dữ liệu
- Sửa nội dung dự án, mục tiêu, vai trò, tiêu chí và phân tích đạo đức trong `js/data.js`.
- Thay liên kết Google Forms tại `project.surveyUrl` nếu cần.
- Thêm hình ảnh vào `assets/images/` và tham chiếu trong HTML/CSS.

## Lưu ý về dữ liệu
- Các minh chứng và điểm đánh giá nhập trực tiếp trên website được lưu trong `localStorage` của trình duyệt hiện tại.
- Dữ liệu localStorage không tự đồng bộ sang máy khác và có thể mất nếu xóa dữ liệu trình duyệt.
- Để cập nhật dữ liệu chính thức cho tất cả người xem, hãy sửa `js/data.js` hoặc thêm tài liệu vào repository rồi commit/push.
- Website không tạo số liệu khảo sát hay điểm thử nghiệm giả. Hãy nhập kết quả thực tế sau khi thu thập.

## Liên kết khảo sát hiện tại
https://docs.google.com/forms/d/e/1FAIpQLScW0PJGK9viXGjxNyDlh2Xe68wWVxoQs9y3fWEk8G-jJFYOzA/viewform?usp=dialog
